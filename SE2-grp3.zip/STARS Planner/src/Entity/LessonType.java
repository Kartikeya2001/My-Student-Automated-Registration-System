package Entity;

/**
 * Enumerator to represent the constants for Lesson type- lecture, tutorial, lab, seminar, online class
 */
public enum LessonType {
	LEC, TUT, LAB, SEM, ONL;
}
