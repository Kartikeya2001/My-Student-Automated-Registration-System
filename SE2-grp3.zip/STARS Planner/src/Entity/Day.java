package Entity;

/**
 * Enumerator to represent the constants for the days of the week
 */
public enum Day {
	SUNDAY, MONDAY, TUESDAY, WEDNESDAY, 
    THURSDAY, FRIDAY, SATURDAY;
}
